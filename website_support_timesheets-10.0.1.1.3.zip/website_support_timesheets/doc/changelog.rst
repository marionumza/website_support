v1.1.3
======
* Group access for timesheet menu

v1.1.2
======
* Tree view for support timesheets

v1.1.1
======
* Remove project field since the other timesheet module is designed for that

v1.1
====
* Pivot view

v1.0.2
======
* Timesheets close template

v1.0.1
======
* Permission fix

v1.0
====
* Upgrade to v10